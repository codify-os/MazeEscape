package phase2.Entity;

import phase2.Tile.Tile;
import phase2.UI.GamePanel;
import phase2.UI.KeyHandler;
import phase2.game.combat.DamageSource;
import phase2.game.stats.Stats;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;


public class Player extends Entity{
    // Constants
    private static final int PLAYER_MAX_HEALTH = 100;
    private static final int PLAYER_ATTACK = 20;
    private static final int PLAYER_DEFENSE = 5;
    private static final int PLAYER_SPEED = 4;
    private static final int ATK_DURATION = 20;
    private static final int TRAP_DAMAGE_FLASH = 15;
    private static final int CRIT_BUFF_DURATION = 180;
    private static final double CRIT_BUFF_CHANCE = 0.1;
    private static final int WIN_POSITION_COL = 48;
    private static final int WIN_POSITION_ROW = 47;
    private static final int ATK_COUNTER = 0;
    private static final int CRIT_BUFF_TIMER = 0;
    
    private final KeyHandler keyH;
    public final int screenX;
    public final int screenY;

    private Image atkUp, atkDown, atkLeft, atkRight;
    private boolean isAttacking = false;
    private int atkCounter = ATK_COUNTER;
    private boolean critBuffActive = false;
    private int critBuffTimer = CRIT_BUFF_TIMER;
    private double prevCritChance;

    private final Map<String, Integer> inventory = new HashMap<>();
    private final Random random = new Random();

    /**
     * Create a player instance
     * @param gp GamePanel instance
     * @param keyH KeyHandler for input
     * @throws IllegalArgumentException if gp or keyH is null
     */
    public Player(GamePanel gp, KeyHandler keyH) {
        super(PLAYER_MAX_HEALTH, new Stats(PLAYER_ATTACK, PLAYER_DEFENSE));
        
        if (gp == null || keyH == null) {
            throw new IllegalArgumentException("GamePanel and KeyHandler cannot be null");
        }
        
        this.gp = gp;
        this.keyH = keyH;

        screenX = gp.screenWidth/2 - (gp.tileSize/2);
        screenY = gp.screenHeight/2 - (gp.tileSize/2);

        this.prevCritChance = stats.getCritChance();

        collisionArea = new Rectangle(8, 16, gp.tileSize - 16, gp.tileSize - 16);
        setDefaultValues();
        getPlayerImage();
    }

    public void setDefaultValues() {
        worldX = gp.tileSize; //spawn x
        worldY = gp.tileSize * 4; //spawn y
        speed = PLAYER_SPEED;
        direction = "down";
    }

    public void getPlayerImage() {
        try{
            Toolkit toolkit = Toolkit.getDefaultToolkit();
            MediaTracker tracker = new MediaTracker(new java.awt.Canvas());
            
            int id = 0;
            up = addImage(toolkit, tracker, "Char_Sprites/char_run_up_anim.gif", id++);
            down = addImage(toolkit, tracker, "Char_Sprites/char_run_down_anim.gif", id++);
            left = addImage(toolkit, tracker, "Char_Sprites/char_run_left_anim.gif", id++);
            right = addImage(toolkit, tracker, "Char_Sprites/char_run_right_anim.gif", id++);
            atkUp = addImage(toolkit, tracker, "Char_Sprites/char_attack_up_anim.gif", id++);
            atkDown = addImage(toolkit, tracker, "Char_Sprites/char_attack_down_anim.gif", id++);
            atkLeft = addImage(toolkit, tracker, "Char_Sprites/char_attack_left_anim.gif", id++);
            atkRight = addImage(toolkit, tracker, "Char_Sprites/char_attack_right_anim.gif", id++);
            
            tracker.waitForAll();
        }catch(InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    private Image addImage(Toolkit toolkit, MediaTracker tracker, String path, int id){
        Image image = toolkit.getImage(gp.getResourceAsImage(path));
        tracker.addImage(image, id);
        return image;
    }
    @Override
    public void update() {
        updateDirection();
        int playerCol = (worldX + collisionArea.x) /gp.tileSize;
        int playerRow = (worldY + collisionArea.y)/gp.tileSize;
        Tile curTile = gp.tileManager.getTile(playerCol, playerRow);
        if (curTile != null && curTile.isTrap) {
            trapDamageHandler(curTile);
        }
        collisionOn = false;
        gp.checkCollision.checkTile(this);
        handleMovement();

        handleAttack();
        updateAttackAnimation();
        updateCritBuff();
        checkWinCondition(playerCol, playerRow);
    }

    private void updateDirection() {
        if(keyH.wPressed) {
            direction = "up";
        } else if (keyH.sPressed) {
            direction = "down";
        } else if (keyH.aPressed) {
            direction = "left";
        } else if (keyH.dPressed){
            direction = "right";
        }
    }

    private void handleMovement() {
        if (keyH.wPressed || keyH.sPressed || keyH.aPressed || keyH.dPressed) {
            if (!collisionOn) {
                switch (direction) {
                    case "up" -> worldY -= speed;
                    case "down" -> worldY += speed;
                    case "left" -> worldX -= speed;
                    case "right" -> worldX += speed;
                }
            }
            collectKey();
        }
    }

    private void handleAttack() {
        if (keyH.spacePressed && !isAttacking) {
            isAttacking = true;
            atkCounter = 0;

            for(Enemy e: new ArrayList<>(gp.enemies)) {
                if (isInRange(e)) {
                    System.out.println("The player is attacking the enemy");
                    attack(e);
                }
            }
        }
    }

    private void updateAttackAnimation() {
        if (isAttacking) {
            atkCounter++;
            if (atkCounter > ATK_DURATION) {
                isAttacking = false;
                atkCounter = 0;
            }
        }
    }

    private void updateCritBuff() {
        if (critBuffActive) {
            if (critBuffTimer <= 0) {
                critBuffActive = false;
                stats.setCritChance(prevCritChance);
            }
        }
    }

    private void checkWinCondition(int playerCol, int playerRow) {
        if (playerCol == WIN_POSITION_COL && playerRow == WIN_POSITION_ROW) {
            if (hasItem("key")) {
                gp.finalScore = (int) (health.getHealthPercentage() * 1000);
                gp.gameState = GamePanel.GameState.GAME_WON;
            }
        }
    }

    private void collectKey() {
        if (gp.droppedKey != null && !gp.droppedKey.collected) {
            Rectangle playerHitBox = new Rectangle(worldX + collisionArea.x,
                    worldY + collisionArea.y, collisionArea.width, collisionArea.height);
            Rectangle keyHitBox = new Rectangle(gp.droppedKey.worldX,
                    gp.droppedKey.worldY, gp.tileSize, gp.tileSize);

            if (playerHitBox.intersects(keyHitBox)) {
                gp.droppedKey.collected = true;
                addItem("key");
            }
        }
    }

    private void trapDamageHandler(Tile curTile) {
        if (curTile.trapTimer > 0) {
            curTile.trapTimer--;
            return;
        }
        health.takeDamage(curTile.trapDamage, new DamageSource("Trap"));
        System.out.println("Trap triggered! Current HP: " + health.getHealthPercentage());
        curTile.trapTimer = curTile.trapCooldown;
        damageFlashTimer = TRAP_DAMAGE_FLASH;
    }

    @Override
    public void draw(Graphics2D g2d){
        Image image = isAttacking ? getAttackSprite() : getMovementSprite();
        Rectangle spriteBounds = isAttacking ? getAttackSpriteDimensions() : getDefaultSpriteDimensions();

        takeDamageFlash(g2d);

        if (image != null) {
            g2d.drawImage(image, spriteBounds.x, spriteBounds.y, spriteBounds.width, spriteBounds.height, null);
        }

        int barWidth = gp.tileSize;
        int barHeight = 4;
        int barX = screenX;
        int barY = screenY - barHeight - 4;
        drawHealthBar(g2d, barX, barY, barWidth, barHeight);

        if(damageTextTimer > 0) {
            showDamage(g2d);
            damageTextTimer--;
        }
    }

    private Image getMovementSprite() {
        return switch (direction) {
            case "up" -> up;
            case "down" -> down;
            case "left" -> left;
            case "right" -> right;
            default -> down;
        };
    }

    private Image getAttackSprite() {
        return switch (direction) {
            case "up" -> atkUp;
            case "down" -> atkDown;
            case "left" -> atkLeft;
            case "right" -> atkRight;
            default -> down;
        };
    }

    private Rectangle getDefaultSpriteDimensions() {
        return new Rectangle(screenX, screenY, gp.tileSize, gp.tileSize);
    }

    private Rectangle getAttackSpriteDimensions() {
        return switch (direction) {
            case "up" -> new Rectangle(screenX - gp.tileSize, screenY - gp.tileSize, gp.tileSize * 3, gp.tileSize * 2);
            case "down" -> new Rectangle(screenX - gp.tileSize, screenY, gp.tileSize * 3, gp.tileSize * 2);
            case "left" -> new Rectangle(screenX - gp.tileSize, screenY - gp.tileSize, gp.tileSize * 2, gp.tileSize * 3);
            case "right" -> new Rectangle(screenX, screenY - gp.tileSize, gp.tileSize * 2, gp.tileSize * 3);
            default -> new Rectangle(screenX - gp.tileSize, screenY, gp.tileSize * 3, gp.tileSize * 2);
        };
    }

    private void showDamage(Graphics2D g2d) {
        String message = "-" + previousDamageAmount;
        int hpStatX = screenX + gp.tileSize/2;
        int hpStatY = screenY - 10 - (30 - damageTextTimer);

        g2d.setColor(Color.black);
        g2d.drawString(message, hpStatX + 2, hpStatY + 2);

        if (lastCrit) {
            g2d.setFont(new Font("Comic Sans", Font.BOLD, 22));
            g2d.setColor(Color.ORANGE);
        } else  {
            g2d.setFont(new Font("Comic Sans", Font.BOLD, 16));
            g2d.setColor(Color.red);
        }
        g2d.drawString(message, hpStatX, hpStatY);
    }

    private void takeDamageFlash(Graphics2D g2d) {
        if (damageFlashTimer > 0) {
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
            g2d.setColor(Color.red);
            g2d.fillRect(screenX, screenY, gp.tileSize, gp.tileSize);
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
            damageFlashTimer--;
        }
    }

    @Override
    public void onDeath() {
        System.out.println("Game Over!");
    }

    public void addItem(String itemName) {
        inventory.put(itemName, inventory.getOrDefault(itemName, 0) + 1);
    }

    public boolean hasItem(String itemName) {
        return inventory.getOrDefault(itemName, 0) > 0;
    }

    public void removeItem(String itemName) {
        if (hasItem(itemName)) {
            inventory.put(itemName, inventory.get(itemName) - 1);
        }
    }

    public Map<String, Integer> getInventory() {
        return inventory;
    }
    public void clearInventory() {
        inventory.clear();
    }

    public void grantRandomBuff() {
        double roll = random.nextDouble();
        if (roll < CRIT_BUFF_CHANCE) {
            activateCritBuff();
            System.out.println("Crit Buff gained");
        }
    }

    public void forceCritBuff() {
        activateCritBuff();
    }

    private void activateCritBuff() {
        prevCritChance = stats.getCritChance();
        stats.setCritChance(1.0);
        critBuffActive = true;
        critBuffTimer = CRIT_BUFF_DURATION;
    }

    public boolean isCritBuffActive() {
        return critBuffActive;
    }
    public int getCritBuffTimer() {
        return critBuffTimer;
    }
}
